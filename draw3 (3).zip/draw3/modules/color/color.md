# Draw Color API — Build Specification (v1.2)

## Purpose

**Import everything with:**
```python
import Draw
from Draw import color, palette
```

This document specifies the authoritative architecture, data types, normalization rules, serialization contracts, animation/expression API, and implementation stages of the Draw Color API (`Draw3`).

**Authority and version scope:** This specification defines the complete public contract for visual styling (fills, borders, drop shadows, outer glows, gradients, and color spaces).
- **Text styling deferred:** Any kind of text/typography fill or styling is **strictly deferred to a future text subsystem**. The Color API focuses exclusively on shape surfaces, outlines, effects, and color spaces.
- **Hardware isolation:** Hardware integration (mouse coordinates `mouse_x`, `mouse_y`, cursor polling, or physical inputs) is **strictly omitted**; input belongs entirely to dedicated event/window subsystems.
- **Strict validation:** All color values are validated strictly via custom exceptions (`DrawColorError`, `InvalidColorValueError`, `UnknownColorNameError`, `InvalidHexColorError`, `ColorTokenCycleError`, `InvalidMotionError`). Silent clamping is forbidden for invalid static inputs.
- **Backend serialization:** Dynamic values use deterministic, JSON-compatible descriptors in the Draw transfer packet schema for consumption by the C++ rendering engine.

---

# PART 1 — Color Entry Point & Callable Namespace Architecture

## 1.1 The `ColorAPI` Callable Namespace Object

To provide both direct function invocation (`Draw.color(...)`) and namespace-level registry operations (`Draw.color.update(...)`, `Draw.color.list(...)`), `Draw.color` is instantiated as a **callable namespace object** (`ColorAPI` / `ColorNamespace`), matching the pattern established by `Draw.shapes` in the Shape module.

```python
class ColorAPI:
    """Callable namespace managing color bindings and scene registry operations."""

    def __call__(
        self,
        name: Optional[str] = None,
        body: Optional[Union["ColorBody", "ColorValue", str, Tuple, Dict, Any]] = None,
        border: Optional[Union["ColorBorder", Dict, Any]] = None,
        shadow: Optional[Union["ColorShadow", Dict, Any]] = None,
        glow: Optional[Union["ColorGlow", Dict, Any]] = None,
        scoped: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ColorBinding":
        """Defines and registers a color binding, or creates an inline shape style."""
        ...

    def update(self, name: str, **kwargs) -> "ColorBinding": ...
    def get(self, name: str) -> "ColorBinding": ...
    def exists(self, name: str) -> bool: ...
    def list(self, name_or_names: Optional[Union[str, Sequence[str]]] = None, data: Optional[List[str]] = None) -> Any: ...
    def copy(self, name: str, new_name: str, link: bool = False) -> "ColorBinding": ...
    def remove(self, names: Union[str, Sequence[str]]) -> int: ...
    def clear(self) -> None: ...
    def theme(self, name: str, tokens: Dict[str, Any]) -> None: ...
    def use_theme(self, name: str) -> None: ...
```

## 1.2 The `ColorBinding` Class Specification

A `ColorBinding` represents a validated, structured style container. It is returned by `Draw.color(...)` and stored in the scene registry.

```python
class ColorBinding:
    """Represents a validated, cohesive visual style binding."""

    def __init__(
        self,
        name: str,
        body: Optional["ColorBody"] = None,
        border: Optional["ColorBorder"] = None,
        shadow: Optional["ColorShadow"] = None,
        glow: Optional["ColorGlow"] = None,
        scoped: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        self.name: str = name
        self.body: Optional["ColorBody"] = body
        self.border: Optional["ColorBorder"] = border
        self.shadow: Optional["ColorShadow"] = shadow
        self.glow: Optional["ColorGlow"] = glow
        self.scoped: bool = scoped
        self.metadata: Dict[str, Any] = metadata or {}

    @property
    def dynamic(self) -> bool:
        """Returns True if any channel contains dynamic motion drivers or expression nodes."""
        return any(
            channel is not None and channel.is_dynamic
            for channel in (self.body, self.border, self.shadow, self.glow)
        )

    def to_dict(self) -> Dict[str, Any]:
        """Serializes binding into authoritative C++ transfer packet schema."""
        return {
            "schema": "draw.color",
            "version": 1,
            "name": self.name,
            "dynamic": self.dynamic,
            "channels": {
                "body": self.body.to_dict() if self.body else None,
                "border": self.border.to_dict() if self.border else None,
                "shadow": self.shadow.to_dict() if self.shadow else None,
                "glow": self.glow.to_dict() if self.glow else None,
            },
            "metadata": self.metadata if self.metadata else None,
        }

    def copy(self, new_name: str) -> "ColorBinding": ...
```

## 1.3 Standard Syntax: Direct Single-Call Definition

Target shape styling is registered under its unique name:

```python
import Draw
from Draw import color

# Define and register color styling for a target shape in a single call
Draw.color(
    name = "red_theme",
    body = color.body(
        fill = color.rgb(255, 0, 0)
    )
)
```

The call creates the `ColorBinding`, validates all color channels, registers it under its unique target `name`, and returns a `ColorBinding` instance for direct object-oriented access.

---

# PART 2 — Shape Integration & Inline Naming Contract

There are two primary ways to connect colors with shapes: **by registered name** and **inline styling**.

## 2.1 Referencing a Registered Color by Name (Recommended for Themes)

When styling is defined separately or reused across elements, `Draw.shape` accepts the registered color's name as a string:

```python
# 1. Register styling in registry
Draw.color(
    name = "card_theme",
    body = color.body(fill="#1e293b"),
    border = color.border(fill="#38bdf8", width=2.0)
)

# 2. Assign to shape by name reference
Draw.shape(
    name = "card_1",
    type = "rectangle",
    size = (300.0, 180.0),
    color = "card_theme"  # References the registered color name
)
```

## 2.2 Inline Styling (`color.IN_SHAPE` Sentinel Lifecycle)

When defining colors directly inside `Draw.shape()`, the `name` parameter in `Draw.color()` is **optional** and defaults to `color.IN_SHAPE` (sentinel value `"$__in_shape__"`):

```python
# Inline anonymous styling
card = Draw.shape(
    name = "card_2",
    type = "rectangle",
    size = (300.0, 180.0),
    color = Draw.color(
        body = color.body(fill="#1e293b"),
        border = color.border(fill="#38bdf8", width=2.0)
    )
)
```

### Lifecycle & Collision Safety Rules:
1. **Unregistered Temporary State:** When `Draw.color()` is invoked with `name=None` or `name=color.IN_SHAPE`, it creates a `ColorBinding` in an unattached/unregistered state. It is **not** placed into the global scene registry immediately, preventing name collisions between multiple inline calls.
2. **Binding Resolution:** When `Draw.shape(name="card_2", color=...)` receives this `ColorBinding`, the shape subsystem renames the binding to match the host shape's name (`"card_2"`) and registers it in the scene color registry under that private host namespace.
3. Both forms are fully valid:
   - `color="card_theme"`: Shared named color asset.
   - `color=Draw.color(...)`: One-off private shape styling.

---

# PART 3 — Color Value Constructors & Normalization

To ensure complete clarity and clean architecture, color values are explicitly separated from shape channel definitions. Users can construct colors using dedicated color constructors (`color.rgb`, `color.rgba`, `color.hsv`, `color.hex`) or use canonical hex strings, named CSS strings, and tuples.

## 3.1 Color Constructors (`color.rgb`, `color.rgba`, `color.hsv`, `color.hex`)

All color constructors return a normalized `ColorValue` instance. Individual channels accept static numeric values, dynamic motion drivers, or expression nodes.

### 3.1.1 `color.rgb(...)` and `color.rgba(...)`
```python
color.rgb(
    r: Union[int, float, Any],
    g: Union[int, float, Any],
    b: Union[int, float, Any],
    a: Union[int, float, Any] = 1.0,
) -> "ColorValue"

color.rgba(
    r: Union[int, float, Any],
    g: Union[int, float, Any],
    b: Union[int, float, Any],
    a: Union[int, float, Any] = 1.0,
) -> "ColorValue"
```
- Accepts either integers in `0–255` or floats in `0.0–1.0`.
- Alpha `a`: If integer `0–255`, normalized to `0.0–1.0`. If float `0.0–1.0`, used directly.

### 3.1.2 `color.hsv(...)`
```python
color.hsv(
    h: Union[float, Any],          # Hue: 0.0 to 360.0 degrees
    s: Union[float, Any] = 100.0,  # Saturation: 0.0 to 100.0 percent
    v: Union[float, Any] = 100.0,  # Value / Brightness: 0.0 to 100.0 percent
    a: Union[float, Any] = 1.0,    # Alpha: 0.0 to 1.0
) -> "ColorValue"
```
- Converted deterministically to RGBA for the C++ rendering pipeline, or serialized as an `"hsv"` descriptor when driven dynamically (e.g. hue cycling).

### 3.1.3 `color.hex(...)`
```python
color.hex(value: str) -> "ColorValue"
```
- Parses `#RGB`, `#RGBA`, `#RRGGBB`, and `#RRGGBBAA` strings into canonical RGBA floats in `[0.0, 1.0]`.

## 3.2 Input Interpretation Table

| Input Format | Channels | Valid Range | Resolution Behavior |
| :--- | :--- | :--- | :--- |
| **`color.rgb(r, g, b)`** | RGB | `0–255` (int) or `0.0–1.0` (float) | Canonical RGBA float `[0.0, 1.0]` in render packets. |
| **`color.rgba(r, g, b, a)`** | RGBA | `0–255` (int) or `0.0–1.0` (float) | Alpha normalized to `0.0–1.0`. |
| **`color.hsv(h, s, v)`** | HSV | $H \in [0, 360)$, $S, V \in [0, 100]$ | Converted to canonical RGBA, or preserved as dynamic HSV descriptor. |
| **Integer Tuple** | RGB: `(r, g, b)` / RGBA: `(r, g, b, a)` | `0` to `255` | Converted to canonical RGBA float `[0.0, 1.0]`. |
| **Float Tuple** | RGB: `(r, g, b)` / RGBA: `(r, g, b, a)` | `0.0` to `1.0` | Detected when channels are floats in `0.0–1.0`. |
| **Hex String** | `#RGB`, `#RGBA`, `#RRGGBB`, `#RRGGBBAA` | Hex chars | Case-insensitive; parsed into canonical RGBA. |
| **Named Color** | String (e.g. `"red"`, `"darkblue"`, `"transparent"`) | CSS/SVG standard | Case-insensitive lookup against standard color table. |

## 3.3 Strict Error Handling Policy

Draw3 does **not silently clamp invalid static color values**. Out-of-bounds or malformed inputs raise explicit exceptions:

```python
# 1. Out of range integers (> 255 or < 0)
color.rgb(300, 0, 0)
# -> Raises: InvalidColorValueError("Channel 'r' value 300 exceeds integer maximum 255.")

# 2. Out of range floats (> 1.0 or < 0.0)
color.rgb(1.5, 0.2, 0.0)
# -> Raises: InvalidColorValueError("Float channel 'r' value 1.5 exceeds maximum 1.0.")

# 3. Invalid Hex
color.hex("#XYZ123")
# -> Raises: InvalidHexColorError("Invalid hexadecimal color string '#XYZ123'.")

# 4. Unknown Named Color
color.body(fill="bluuue")
# -> Raises: UnknownColorNameError("Unknown color name 'bluuue'.")

# 5. Mixed integer and float tuples out of unit bounds
(200, 0.5, 0)
# -> Raises: InvalidColorValueError("Mixed channel types must conform to 0-255 integer scale.")
```

---

# PART 4 — Channel Sub-Constructors

Styling is structured into explicit, type-safe target channels created via sub-constructors on `color.*`:

```text
color.body(...)   -> Shape interior fill
color.border(...) -> Shape outline stroke
color.shadow(...) -> Drop shadow effect
color.glow(...)   -> Outer neon glow effect
```

*(Note: Text fill and typography styling are strictly deferred to future text subsystems).*

---

## 4.1 `color.body(...)`

Controls the shape's interior fill:

```python
body = color.body(
    fill: Union[str, Tuple, "ColorValue", "ColorGradient"] = "#1e293b",
    opacity: Union[float, Any] = 1.0,
    blend: str = "normal",
    filters: Optional[Sequence["ColorFilter"]] = None,
)
```

### Examples:
```python
# Using color.rgb
Draw.color(
    name = "red_box",
    body = color.body(fill=color.rgb(220, 38, 38))
)

# Using dynamic HSV
Draw.color(
    name = "rainbow_box",
    body = color.body(
        fill = color.hsv(
            h = color.cycle(speed=60.0),
            s = 90.0,
            v = 100.0,
        )
    )
)
```

---

## 4.2 `color.border(...)`

Controls the shape's outline stroke:

```python
border = color.border(
    fill: Union[str, Tuple, "ColorValue", "ColorGradient"] = "#38bdf8",
    width: Union[float, Any] = 1.0,
    style: str = "solid",    # "solid", "dashed", "dotted"
    opacity: Union[float, Any] = 1.0,
    blend: str = "normal",
)
```

### Examples:
```python
Draw.color(
    name = "card",
    body = color.body(fill="#0f172a"),
    border = color.border(
        fill = color.rgb(56, 189, 248),
        width = 2.0,
        style = "solid"
    )
)
```

---

## 4.3 `color.shadow(...)`

Controls drop shadows:

```python
shadow = color.shadow(
    fill: Union[str, Tuple, "ColorValue"] = "black",
    blur: Union[float, Any] = 16.0,
    spread: Union[float, Any] = 0.0,
    offset: Tuple[Union[float, Any], Union[float, Any]] = (0.0, 4.0),
    opacity: Union[float, Any] = 0.5,
    inner: bool = False,
)
```

---

## 4.4 `color.glow(...)`

Controls outer neon glows:

```python
glow = color.glow(
    fill: Union[str, Tuple, "ColorValue"] = "cyan",
    blur: Union[float, Any] = 24.0,
    spread: Union[float, Any] = 0.0,
    opacity: Union[float, Any] = 0.8,
)
```

---

## 4.5 Color Operations, Blend Modes & Filters

Composable color operations and filters are applied in documented order and serialized as data—never as opaque Python callbacks.

```python
Draw.color(
    name = "glass_panel",
    body = color.body(
        fill = "#38bdf8",
        opacity = 0.28,
        blend = "screen",
        filters = [
            color.filter("saturate", 1.15),
            color.filter("brightness", 1.05),
        ],
    ),
    border = color.border(
        fill = "#bae6fd",
        width = 1.5,
        opacity = 0.8,
    ),
)
```

### Supported blend modes
- `normal`
- `multiply`
- `screen`
- `overlay`
- `darken`
- `lighten`
- `add`
- `difference`

Unknown blend modes raise `ValueError`.

### Supported filters constructor
```python
color.filter(name: str, amount: Union[float, Any] = 1.0) -> "ColorFilter"
```

Available filter names:
- `brightness` (amount: float, default 1.0)
- `contrast` (amount: float, default 1.0)
- `saturate` (amount: float, default 1.0)
- `grayscale` (amount: float, 0.0 to 1.0)
- `invert` (amount: float, 0.0 to 1.0)
- `sepia` (amount: float, 0.0 to 1.0)
- `hue_rotate` (degrees: float, in degrees)

### Alpha / Opacity Composition
A color may contain alpha in its source value and also have a channel-level `opacity`. The final alpha is:
```python
final_alpha = source_alpha * channel_opacity
```
Each value is normalized to `0.0–1.0`. Source alpha is preserved and modulated, never discarded.

---

# PART 5 — Gradients (`color.gradient`)

Draw3 supports Linear, Radial, and Conical gradients assigned directly to `fill` across `body` or `border`:

```python
gradient = color.gradient(
    type: str = "linear",                                # "linear", "radial", "conical"
    angle: Union[float, Any] = 0.0,                       # In degrees (linear / conical starting angle)
    center: Tuple[float, float] = (50.0, 50.0),           # % coordinates for radial/conical
    radius: float = 50.0,                                # % spread for circular radial
    radius_x: Optional[float] = None,                    # Optional elliptical x radius
    radius_y: Optional[float] = None,                    # Optional elliptical y radius
    stops: Sequence[Tuple[Union[float, str], Any]] = (),  # (offset, color) pairs
    spread: str = "pad",                                 # "pad", "repeat", "reflect"
    interpolation: str = "srgb",                         # "srgb" or "linear"
    space: str = "shape",                                # "shape" or "scene"
    transform: Optional[Dict[str, Any]] = None,          # Optional transform dictionary
)
```

## 5.1 Gradient Stops & Options

Gradient stops accept either normalized numeric offsets (`0.0` to `1.0`) or percentage strings (`"0%"` to `"100%"`). Stops are sorted by offset during normalization. Duplicate offsets are allowed and represent a hard color transition.

```python
grad = color.gradient(
    type = "linear",
    angle = 35.0,
    stops = [
        (0.0, color.rgb(14, 165, 233)),
        (0.55, "#8b5cf6"),
        (1.0, color.rgb(244, 63, 94)),
    ],
    spread = "pad",
    interpolation = "srgb",
    space = "shape",
)
```

---

# PART 6 — Dynamic Values & Serialization Contract

Dynamic evaluations are driven by **animation clock time (`time`)**, procedural math drivers, and live data bindings (`Draw.live`). Hardware input is handled by dedicated event/window subsystems.

## 6.1 Semantic Motion Drivers

### 6.1.1 Constructor Signatures

```python
# 1. Continuous rotation / cycle
color.cycle(
    speed: float = 60.0,           # Units per second (e.g. degrees/sec for hue)
    offset: float = 0.0,          # Starting phase offset
    repeat: Optional[int] = None, # None = infinite
    yoyo: bool = False,
    delay: float = 0.0,
    enabled: bool = True,
    fallback: Optional[float] = None,
) -> "MotionDriver"

# 2. Smooth oscillating breathing between min and max
color.pulse(
    min_val: float = 0.0,
    max_val: float = 1.0,
    speed: float = 1.0,           # Frequency in Hz
    easing: str = "smooth",
    repeat: Optional[int] = None,
    yoyo: bool = False,
    delay: float = 0.0,
    enabled: bool = True,
    fallback: Optional[float] = None,
) -> "MotionDriver"

# 3. Direct range oscillation
color.oscillate(
    from_val: float = 0.0,
    to_val: float = 1.0,
    duration: float = 1.0,        # Period in seconds
    easing: str = "ease_in_out",
    repeat: Optional[int] = None,
    yoyo: bool = True,
    delay: float = 0.0,
    enabled: bool = True,
    fallback: Optional[float] = None,
) -> "MotionDriver"
```

### 6.1.2 Usage Examples

```python
# 1. Rotating hue on body
Draw.color(
    name = "rainbow_box",
    body = color.body(
        fill = color.hsv(
            h = color.cycle(speed=60.0),
            s = 90.0,
            v = 100.0,
        )
    ),
    border = color.border(
        fill = color.hsv(
            h = color.cycle(speed=60.0, offset=180.0),
            s = 100.0,
            v = 100.0,
        ),
        width = 2.0,
    )
)

# 2. Pulsing glow blur
Draw.color(
    name = "beacon",
    body = color.body(fill="crimson"),
    glow = color.glow(
        fill = "red",
        blur = color.pulse(min_val=10.0, max_val=40.0, speed=2.0),
    )
)
```

## 6.2 Deterministic Dynamic Serialization Contract

When any channel contains dynamic motion drivers or reactive math, `to_dict()` marks `"dynamic": true` and serializes **explicit motion descriptors**. This enables external C++ renderers or worker threads to evaluate the animation without executing Python code:

### Serialized Dynamic Output (Strictly Matching Section 10.1):
```json
{
  "schema": "draw.color",
  "version": 1,
  "name": "rainbow_box",
  "dynamic": true,
  "channels": {
    "body": {
      "fill": {
        "type": "hsv",
        "h": {
          "type": "cycle",
          "speed": 60.0,
          "offset": 0.0
        },
        "s": 90.0,
        "v": 100.0,
        "a": 1.0
      },
      "opacity": 1.0,
      "blend": "normal",
      "filters": []
    },
    "border": {
      "fill": {
        "type": "hsv",
        "h": {
          "type": "cycle",
          "speed": 60.0,
          "offset": 180.0
        },
        "s": 100.0,
        "v": 100.0,
        "a": 1.0
      },
      "width": 2.0,
      "style": "solid",
      "opacity": 1.0,
      "blend": "normal"
    },
    "shadow": null,
    "glow": null
  },
  "metadata": null
}
```

### Motion Descriptor Schemas:
* **`cycle`**: `{"type": "cycle", "speed": float, "offset": float, "delay": float, "enabled": bool}`
* **`pulse`**: `{"type": "pulse", "min": float, "max": float, "speed": float, "easing": str, "delay": float, "enabled": bool}`
* **`oscillate`**: `{"type": "oscillate", "from": float, "to": float, "duration": float, "easing": str, "repeat": int|null, "yoyo": bool}`
* **`expression`**: `{"type": "expression", "expr": { ... }}`

---

## 6.3 Expression Builder — Structured Mathematical Nodes

A raw expression string such as `"time * 4"` is valid as an internal serialized representation, but is never the preferred user-facing API. Draw exposes expression objects that compose via standard Python operators and serialize into structured AST trees.

```python
# Drive hue procedurally via animation clock
Draw.color(
    name = "animated_hue",
    body = color.body(
        fill = color.hsv(
            h = color.expr(color.time * 45 + 20),
            s = 90.0,
            v = 100.0,
        )
    )
)
```

### Expression API
```python
color.time                       # Animation clock in seconds (ExpressionNode)
color.expr(value)                # Normalizes value into an ExpressionNode
color.sin(expr)                  # Sine
color.cos(expr)                  # Cosine
color.abs(expr)                  # Absolute value
color.min(a, b, ...)             # Minimum
color.max(a, b, ...)             # Maximum
color.clamp(expr, low, high)     # Clamp expression result
color.lerp(start, end, amount)   # Linear interpolation
color.map(expr, in_min, in_max, out_min, out_max)
```

Expressions support safe arithmetic operators: `+`, `-`, `*`, `/`, `//`, `%`, `**`, and unary `-`. Arbitrary Python calls, attribute lookups, file access, and `eval()` are **strictly forbidden**.

---

## 6.4 Keyframe Animation & Transitions

For authored timelines:

```python
# Keyframe timeline
anim = color.keyframes(
    property = "body.fill.h",
    frames = [
        (0.0, 210.0),
        (1.0, 300.0),
        (2.0, 30.0),
    ],
    easing = "ease_in_out",
    repeat = None,
    yoyo = True,
)

# Smooth transition on update
Draw.color.update(
    "card_theme",
    transition = color.transition(
        duration = 0.35,
        easing = "ease_out",
    ),
    body = color.body(fill="#f97316"),
)
```

---

## 6.5 Reduced Motion & Static Fallback

For accessibility and deterministic previews, all motion drivers accept an optional `fallback`:

```python
color.pulse(
    min_val = 0.2,
    max_val = 1.0,
    speed = 1.5,
    fallback = 0.65,
)
```

When reduced motion is enabled (`Draw.animation.set_reduced_motion(True)`), animations freeze at their explicit `fallback` or initial value.

---

# PART 7 — Color Harmonies & References

Draw3 provides procedural color-theory helpers that link dynamically to other channels or shape colors:

```python
Draw.color(
    name = "panel",
    body = color.body(
        fill = color.hsv(h=color.cycle(speed=45.0), s=90.0, v=100.0)
    ),
    # Automatically resolves to the exact complement of this shape's body (+180 deg)
    border = color.border(
        fill = color.complement("panel.body"),
        width = 3.0,
    )
)
```

## 7.1 Harmony Helpers

```python
color.complement(source, angle=180.0)
color.analogous(source, angle=30.0, count=3)
color.triadic(source)
color.split_complementary(source, angle=150.0)
color.tetradic(source, angle=90.0)
color.monochromatic(source, count=5)
color.mix(first, second, amount=0.5, space="srgb")
color.lighten(source, amount=0.1)
color.darken(source, amount=0.1)
color.with_alpha(source, alpha=0.5)
```

### Reference Rules:
- A string reference such as `"panel.body"` resolves to that binding's channel fill.
- Unresolved references raise `UnknownColorNameError`.
- Harmonies applied to dynamic HSV sources remain linked to the live motion descriptor.
- All harmonies preserve source alpha unless explicitly overridden.

---

# PART 8 — Color Registry API

The `ColorAPI` object exposes full lifecycle methods matching `Draw.shapes`:

```python
# 1. Update specific channels (omitted channels are left untouched)
Draw.color.update(
    name = "card_theme",
    body = color.body(fill="crimson"),
    border = color.border(fill="gold", width=3.0),
)

# 2. Query active styling
data = Draw.color.list("card_theme", data=["body", "border"])

# 3. Check existence
if Draw.color.exists("card_theme"):
    print("Color binding is active")

# 4. Clone styling
Draw.color.copy("card_theme", new_name="card_theme_accent")

# 5. Remove styling
Draw.color.remove(["card_theme"])

# 6. Clear registry
Draw.color.clear()
```

---

# PART 9 — Palette & Design Tokens (`Draw.palette`)

The palette provides a centralized design-token system that integrates directly with scene theming.

```python
from Draw import palette

# 1. Define global design tokens
Draw.palette(
    primary = "#3b82f6",
    surface = "#1e293b",
    danger = "#ef4444",
    border = "#334155",
)

# 2. Use design tokens directly in color definitions
Draw.color(
    name = "submit_btn",
    body = color.body(fill=palette.primary),
    border = color.border(fill=palette.border, width=1.0),
)
```

## 9.1 Theme Integration & Token Resolution

`Draw.color.theme` connects themes directly to `Draw.palette`:

```python
# Define named themes
Draw.color.theme(
    name = "dark",
    tokens = {
        "primary": "#60a5fa",
        "surface": "#0f172a",
        "border": "#334155",
    },
)

Draw.color.theme(
    name = "light",
    tokens = {
        "primary": "#2563eb",
        "surface": "#ffffff",
        "border": "#e2e8f0",
    },
)

# Switch theme at runtime: updates Draw.palette tokens dynamically
Draw.color.use_theme("dark")
```

- Tokens may reference other tokens; cyclic dependencies raise `ColorTokenCycleError`.
- Missing tokens produce an immediate, clear `UnknownColorNameError`.

---

# PART 10 — Serialization & C++ Renderer Contract

## 10.1 Deterministic Packet Schema

Every serialized color binding adheres strictly to the following dictionary structure:

```json
{
  "schema": "draw.color",
  "version": 1,
  "name": "string",
  "dynamic": false,
  "channels": {
    "body": {
      "fill": [0.12, 0.16, 0.23, 1.0],
      "opacity": 1.0,
      "blend": "normal",
      "filters": []
    },
    "border": {
      "fill": [0.22, 0.74, 0.97, 1.0],
      "width": 2.0,
      "style": "solid",
      "opacity": 1.0,
      "blend": "normal"
    },
    "shadow": null,
    "glow": null
  },
  "metadata": null
}
```

## 10.2 Validation Checklist

The Python API applies these invariants before sending packets to the renderer:
- All channel numeric values are finite numbers; reject `NaN` and `Infinity`.
- Hex strings are valid 3, 4, 6, or 8-digit hex values.
- Integer RGB values are within `0–255`; float RGB values are within `0.0–1.0`.
- Hue values are normalized modulo 360.0.
- Border widths and blur/spread radii are non-negative.
- Blend modes, easing names, filter names, and expression operations are from the authorized white-list.

---

# PART 11 — Exception Hierarchy

All exceptions raised by the Color API inherit from `DrawColorError`:

```python
class DrawColorError(Exception):
    """Base exception for all Draw Color API errors."""

class InvalidColorValueError(DrawColorError):
    """Raised when a color channel, opacity, or coordinate value is out of valid bounds."""

class UnknownColorNameError(DrawColorError):
    """Raised when a named color or referenced token cannot be resolved."""

class InvalidHexColorError(DrawColorError):
    """Raised when a hexadecimal color string contains invalid formatting or characters."""

class ColorTokenCycleError(DrawColorError):
    """Raised when design tokens or themes form a circular dependency."""

class InvalidMotionError(DrawColorError):
    """Raised when an animation driver or motion parameter is invalid or unsupported."""
```

---

# PART 12 — Phased Implementation Priority

```text
Phase 1: Core Color System & Representations
  ├── Color representations (color.rgb, color.rgba, color.hsv, color.hex)
  ├── Strict validation & exceptions (InvalidColorValueError, UnknownColorNameError)
  ├── Channel sub-constructors (color.body, color.border)
  └── Static working data serialization (ColorBinding.to_dict())

Phase 2: Effects, Blends & Gradients
  ├── Shadow and Glow channel models (color.shadow, color.glow)
  ├── Gradients (color.gradient: linear, radial, conical)
  ├── Blend modes and filters (color.filter)
  └── Opacity and alpha composition

Phase 3: Registry, Palette & Shape Integration
  ├── ColorAPI callable namespace implementation
  ├── ColorBinding lifecycle & inline shape styling (color.IN_SHAPE)
  ├── SceneRegistry synchronization (Draw.color.update, list, copy, remove)
  └── Design tokens & theme engine (Draw.palette, Draw.color.theme, Draw.color.use_theme)

Phase 4: Dynamic Motion Engine
  ├── Motion drivers (color.cycle, color.pulse, color.oscillate)
  ├── Structured motion descriptor serialization ({ "dynamic": true, ... })
  ├── Pure animation clock & deterministic seeking
  └── Reduced-motion static fallbacks

Phase 5: Expression Builder & Timeline
  ├── Safe expression nodes (color.time, color.sin, color.lerp, color.clamp)
  ├── Keyframe animation (color.keyframes) & runtime transitions (color.transition)
  └── AST validation & descriptor serialization

Phase 6: Color Harmonies & Advanced Collections
  ├── Procedural color harmonies (color.complement, color.analogous, color.mix)
  └── Dynamic cross-channel references
```

---

# Appendix — Public API Design Principles

1. **Clean Separation of Concerns:** Color values (`color.rgb`, `color.hsv`, etc.) are distinct from shape styling channels (`color.body`, `color.border`, `color.shadow`, `color.glow`).
2. **Text is Future Scope:** Text typography and styling are deferred to future text modules.
3. **Structured Expression Nodes:** Expressions are composed with normal Python objects (e.g. `color.time * 45`), not raw unvalidated strings or `eval()`.
4. **Predictable Errors:** Errors fail fast with descriptive custom exceptions rather than silently clamping inputs.
5. **Deterministic Serialization:** Python outputs JSON-compatible descriptors that the C++ engine renders with zero Python runtime dependency.
